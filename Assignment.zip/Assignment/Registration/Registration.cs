﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace Registration
{
    [TestClass]
    public class Registration
    {

        public static IWebDriver WebDriver;
        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {

            WebDriver = new ChromeDriver();

        }

        /// <summary>
        /// Test Method to verify the registartion form for diffrent input
        /// </summary>
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "|DataDirectory|\\TestData.csv", "TestData#csv", DataAccessMethod.Sequential), TestMethod]
        public void RegistrationTest()
        {
            
            try
            {
                #region Decleration

                //Read values from data source(like CSV ,XML etc)
                var _firstName = TestContext.DataRow["firstName"].ToString();
                var _lastName = TestContext.DataRow["lastName"].ToString();
                var _userName = TestContext.DataRow["userName"].ToString(); 
                var _userPassword = TestContext.DataRow["userPassword"].ToString(); 
                var _confirmPassword = TestContext.DataRow["confirmPassword"].ToString(); 
                var _email = TestContext.DataRow["email"].ToString(); 
                var _department = TestContext.DataRow["department"].ToString(); 
                var _contactNo = TestContext.DataRow["contactNo"].ToString().TrimStart('0');

                #endregion

                #region LuanchUrlInChrome
                //Goto the Target website
                WebDriver.Navigate().GoToUrl("http://adjiva.com/qa-test/");
                WebDriver.Manage().Window.Maximize();
                #endregion

                var department = GetElement("//select[@name='department']");
                var selectDepartmentItem = new SelectElement(department);
                var submit_Button = GetElement("//button[@type='submit']");

                #region ScenerioImplementation
                //Fill The Value and validate it 
                if (_firstName.Length >= 2)
                {
                    Validation("first_name", _firstName, true);
                }
                else
                {
                    Validation("first_name", _firstName, false);
                }

                if (_lastName.Length >= 2)
                {
                    Validation("last_name", _lastName, true);
                }
                else
                {
                    Validation("last_name", _lastName, false);
                }

                selectDepartmentItem.SelectByText(_department);

                if (_userName.Length >= 8)
                {
                    Validation("user_name", _userName, true);
                }
                else
                {
                    Validation("user_name", _userName, false);
                }

                if (_userPassword.Length >= 8)
                {
                    Validation("user_password", _userPassword, true);
                }
                else
                {
                    Validation("user_password", _userPassword, false);
                }

                if (_confirmPassword.Length == 8)
                {
                   
                    if (_userPassword == _confirmPassword)
                    {
                        Validation("confirm_password", _confirmPassword, true);
                    }
                    else
                    {
                        Validation("confirm_password", _confirmPassword, false);
                    }
                }
                else
                {
                    Validation("confirm_password", _confirmPassword, false);
                }

                if (_email.Length >= 10)
                {
                    Validation("email", _email, true);
                }
                else
                {
                    Validation("email", _email, false);
                }

                if (_contactNo.Length == 10)
                {
                    Validation("contact_no", _contactNo, true);
                }
                else
                {
                    Validation("contact_no", _contactNo, false);
                }

                #endregion
                
                //Click On Submit
               // submit_Button.Click();

            }
            catch(Exception exe)
            {
                throw exe;
            }
        }


        [TestCleanup()]
        public void MyTestCleanup()
        {
            //Clean up the instance
            WebDriver.Quit();
        }

        public TestContext TestContext { get; set; }
        /// <summary>
        /// Get the Element From the DOM using xpath
        /// </summary>
        /// <param name="xpath">xpath of Control</param>
        /// <returns>Return the web element</returns>
        public IWebElement GetElement(string xpath)
        {

            return WebDriver.FindElement(By.XPath(xpath));
        }

        /// <summary>
        /// Set the Text to the control
        /// </summary>
        /// <param name="controlName">Name attribute of the control</param>
        /// <param name="value">Value to set to text box</param>
        public void SetTextTo(string controlName,string value)
        {
            var element = GetElement("//input[@name='" + controlName + "']");
            element.Clear();
            element.SendKeys(value);
            Console.WriteLine("Setting Text '{0}' to control '{1}'", value,controlName); // Logging message on standard ouput window
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="controlName"></param>
        /// <param name="value"></param>
        /// <param name="validationParameter"></param>
        public void Validation(string controlName,string value,bool validationParameter)
        {
            SetTextTo(controlName, value);

            if (validationParameter)
            {
                var validation = GetElement("//input[@name='"+ controlName + "']//../i");
                Assert.IsTrue(validation.GetAttribute("class").Contains("ok"),"validation failure to return success for - "+controlName); 
                Console.WriteLine("Validation Sucess with criteria for '{0}'",controlName); //Logging message on standard ouput window
            }
            else
            {
                var validation = GetElement("//input[@name='" + controlName + "']//../i");
                Assert.IsTrue(validation.GetAttribute("class").Contains("remove"), "validation failure for - " + controlName);
                Console.WriteLine("Validation Failure is sucess with criteria for '{0}'", controlName);//Logging message on standard ouput window
            }
        }

    }
}
