I have create two main sceanrio and automate them:
1- Based on Airline Name
2- Based on lowest price
3- Flight booking without User details

There could be other scenarios like flight based on shortest duration or combination of lower price and short duration which also can be automated.
3rd scenario was interesting because I was thinking to automate as negative scenario but website is allowing that to happen.