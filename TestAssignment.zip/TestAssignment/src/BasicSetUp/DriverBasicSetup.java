package BasicSetUp;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;


public class DriverBasicSetup 

{
	
  public static WebDriver driver = null;  
	 
  @BeforeTest 
  public static WebDriver basicSetUp() throws IOException 
  { 
	String driverDirectory = System.getProperty("user.dir");	
	driverDirectory = driverDirectory+"\\BrowserDriver\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver",driverDirectory);
	driver = new ChromeDriver();  
    driver.manage().window().maximize();  
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
    driver.get("https://blazedemo.com/"); 
    String title = "BlazeDemo";
    Assert.assertEquals(title, driver.getTitle());
    System.out.println("Successfully Navigated to BlazeDemo website");
    return driver;
}  
}
