package Test;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import BasicSetUp.DriverBasicSetup;
import BlazeDemo.ConfirmationPage;
import BlazeDemo.FlightSelectPage;
import BlazeDemo.FlightUserDataEntry;
import BlazeDemo.MainPage;

public class BlazeDemoTest  
{
	 WebDriver driver;
	 Properties obj = new Properties();

	@BeforeMethod
	public void OpenBrowser()throws IOException 
	{
     driver = DriverBasicSetup.basicSetUp();
	
	 //Properties Declaration Area	 
	  String dir = System.getProperty("user.dir");	  	 
	  dir = dir+"\\src\\BlazedemoProperties";
	  FileInputStream objfile = new FileInputStream(dir);
	  obj.load(objfile);
	  	 
	}
  	
	
	  @Test(priority = 0) 
	  public void TicketBookingEndToEndFLowBasedOnAirlineSelection() throws IOException 
	  { 		  
		  MainPage mp = new MainPage(driver);
		  FlightSelectPage flightSelect = new  FlightSelectPage(driver);
		  FlightUserDataEntry userDetail = new FlightUserDataEntry(driver);
		  ConfirmationPage confirm = new ConfirmationPage(driver);
		    		 
		  String fromCity = obj.getProperty("FromCity");
		  String toCity = obj.getProperty("ToCity"); 
		  String fullName = obj.getProperty("FullName"); 
		  String address = obj.getProperty("Address"); 
		  String city = obj.getProperty("City"); 
		  String state = obj.getProperty("State"); 
		  String zipCode = obj.getProperty("ZipCode"); 
		  String cardType = obj.getProperty("CardType"); 
		  String cardNum = obj.getProperty("CardNum"); 
		  String month = obj.getProperty("Month"); 
		  String year = obj.getProperty("Year");
		  String nameOnCard = obj.getProperty("NameOnCard");
		  
		    
		  //Test Steps
		  
		    //Select From and To City Destination for Flight booking
		    flightSelect =  mp.findFlight(fromCity, toCity);
		    System.out.println("Find Flight Complete");
			flightSelect.verifyFlightSelectionPage(fromCity, toCity);
			System.out.println("Find Flight Page Confirmed");
			
			//Select Flight Based on Airline 
			flightSelect.clickOnChooseFlightButtonBasedOnAirlineName(obj.getProperty("AirlineName"));
			System.out.println("Successfully selected the flight based on Airline name");
			
			//User Data Entry
			System.out.println("Enter User Personal Details");
			userDetail.enterFullName(fullName);
			userDetail.enterAddress(address);
			userDetail.enterCity(city);
			userDetail.enterState(state);
			userDetail.enterZipCode(zipCode);
			userDetail.selectCardType(cardType);
			userDetail.enterCreditCardNumber(cardNum);
			userDetail.enterCreditCardMonth(month);
			userDetail.enterCreditCardYear(year);
			userDetail.enterNameOnCard(nameOnCard);		
			userDetail.clickOnPurchaseFlightButton();				
			confirm.verifyFlightSelectionPage();
			System.out.println("User Details entered Sucessfully");
			System.out.println("Flight booking confrimed with given destination");
			
			//Flight ID Confirmation 
			confirm.getTicketIdConfirmation();
			System.out.println("Sucessfully verfied the booking ID");
					 
	}    	     
 
  @Test(priority = 1) 
  public void TicketBookingEndToEndFLowBasedOnLowestPrice() throws IOException 
  { 
	  MainPage mp = new MainPage(driver);
	  FlightSelectPage flightSelect = new  FlightSelectPage(driver);
	  FlightUserDataEntry userDetail = new FlightUserDataEntry(driver);
	  ConfirmationPage confirm = new ConfirmationPage(driver);
	    		 
	  String fromCity = obj.getProperty("FromCity");
	  String toCity = obj.getProperty("ToCity"); 
	  String fullName = obj.getProperty("FullName"); 
	  String address = obj.getProperty("Address"); 
	  String city = obj.getProperty("City"); 
	  String state = obj.getProperty("State"); 
	  String zipCode = obj.getProperty("ZipCode"); 
	  String cardType = obj.getProperty("CardType"); 
	  String cardNum = obj.getProperty("CardNum"); 
	  String month = obj.getProperty("Month"); 
	  String year = obj.getProperty("Year");
	  String nameOnCard = obj.getProperty("NameOnCard");
	  
	    
	  //Test Steps
	  
	    //Select From and To City Destination for Flight booking
	    flightSelect =  mp.findFlight(fromCity, toCity);
	    System.out.println("Find Flight Complete");
		flightSelect.verifyFlightSelectionPage(fromCity, toCity);
		System.out.println("Find Flight Page Confirmed");
		
		//Select Flight Based on Airline 
		flightSelect.clickOnChooseFlightButtonBasedOnLowestPrice();
		System.out.println("Successfully selected the flight based on lowest price");
		
		//User Data Entry
		System.out.println("Enter User Personal Details");
		userDetail.enterFullName(fullName);
		userDetail.enterAddress(address);
		userDetail.enterCity(city);
		userDetail.enterState(state);
		userDetail.enterZipCode(zipCode);
		userDetail.selectCardType(cardType);
		userDetail.enterCreditCardNumber(cardNum);
		userDetail.enterCreditCardMonth(month);
		userDetail.enterCreditCardYear(year);
		userDetail.enterNameOnCard(nameOnCard);		
		userDetail.clickOnPurchaseFlightButton();				
		confirm.verifyFlightSelectionPage();
		System.out.println("User Details entered Sucessfully");
		System.out.println("Flight booking confrimed with given destination");
		
		//Flight ID Confirmation 
		confirm.getTicketIdConfirmation();
		System.out.println("Sucessfully verfied the booking ID");
				 
} 
  
  @Test(priority = 1) 
  public void TicketBookingEndToEndFLowWithoutUserDetail() throws IOException 
  { 
	  MainPage mp = new MainPage(driver);
	  FlightSelectPage flightSelect = new  FlightSelectPage(driver);
	  FlightUserDataEntry userDetail = new FlightUserDataEntry(driver);
	  ConfirmationPage confirm = new ConfirmationPage(driver);
	    		 
	  String fromCity = obj.getProperty("FromCity");
	  String toCity = obj.getProperty("ToCity"); 	  
	    
	  //Test Steps
	  
	    //Select From and To City Destination for Flight booking
	    flightSelect =  mp.findFlight(fromCity, toCity);
	    System.out.println("Find Flight Complete");
		flightSelect.verifyFlightSelectionPage(fromCity, toCity);
		System.out.println("Find Flight Page Confirmed");
		
		//Select Flight Based on Airline 
		flightSelect.clickOnChooseFlightButton();
		System.out.println("Successfully selected the flight");
			
		userDetail.clickOnPurchaseFlightButton();				
		confirm.verifyFlightSelectionPage();
		System.out.println("User Details entered Sucessfully");
		System.out.println("Flight booking confrimed with given destination");
		
		//Flight ID Confirmation 
		confirm.getTicketIdConfirmation();
		System.out.println("Sucessfully verfied the booking ID");
				 
} 
  
  
  @AfterMethod
  public void closingTest() 
  { 
	  driver.quit(); 
  } 


}

