package BlazeDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class ConfirmationPage {
	
	 WebDriver driver; 

	  public ConfirmationPage(WebDriver driver) 
	  { 
	    this.driver = driver; 
	  } 

	  By thankYouText = By.xpath("//h1[contains(text(),'Thank you for your purchase today!')]");
	  By ticketIDNumber = By.xpath("//td[contains(text(),'Id')]/following-sibling::td");
	  By ticketDetailArea = By.xpath("//pre");
	  
	  public void getTicketIdConfirmation()
	  {	  
		  WebElement getID = driver.findElement(ticketIDNumber);
	      String idNum = getID.getText();
	      
	      WebElement confirmText = driver.findElement(ticketDetailArea);
	      String details = confirmText.getText();
	      boolean check = details.contains(idNum);
	      Assert.assertTrue(check);	      
	  }
	  
	  public void verifyFlightSelectionPage()
	  {	       
	      WebElement text = driver.findElement(thankYouText);
	      String getFlightHeaderText = text.getText();
	      Assert.assertEquals("Thank you for your purchase today!", getFlightHeaderText);
	  }

}
