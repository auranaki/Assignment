package BlazeDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class MainPage {
	
    WebDriver driver; 

  public MainPage(WebDriver driver) 
  { 
    this.driver = driver; 
  } 

  By departureCity = By.name("fromPort");
  By destinationCity = By.name("toPort");
  By findFlight = By.xpath("//input[@class='btn btn-primary']");

//Create a method to perform operations on each web element. 
  public FlightSelectPage findFlight(String departureCityName, String destinationCityName)
  {    
      Select selectDepartureCity = new Select(driver.findElement(departureCity));
      selectDepartureCity.selectByVisibleText(departureCityName);

      Select selectdestinationCity = new Select(driver.findElement(destinationCity));
      selectdestinationCity.selectByVisibleText(destinationCityName);

      WebElement login = driver.findElement(findFlight);
      login.click();
      return new FlightSelectPage(driver);
  }
  
}
