package BlazeDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;



public class FlightSelectPage {

	  WebDriver driver; 

	  public FlightSelectPage(WebDriver driver) 
	  { 
	    this.driver = driver; 
	  } 

	  By flightHeader = By.xpath("//h3[contains(text(),'Flights from')]");
	  
	  	
	  public void verifyFlightSelectionPage(String departureCityName, String destinationCityName )
	  {	       
	      WebElement text = driver.findElement(flightHeader);
	      String getFlightHeaderText = text.getText();
	      Assert.assertEquals("Flights from "+departureCityName+" to "+destinationCityName+":", getFlightHeaderText);
	  }
	  
	  public FlightUserDataEntry clickOnChooseFlightButtonBasedOnAirlineName(String airlineName)
	  {
		  By flightSelection = By.xpath("//td[text()='"+airlineName+"']//parent::tr//input[@class='btn btn-small']"); 
		  System.out.println("Select the Flight");	  
	      WebElement flightSelect = driver.findElement(flightSelection);
	      flightSelect.click();
	      return new FlightUserDataEntry(driver);
	  }
	  
	  public FlightUserDataEntry clickOnChooseFlightButtonBasedOnLowestPrice()
	  {
		  By flightSelection = By.xpath("//tr//td[last()]"); 
		  System.out.println("Select the Flight");	  
	      List<WebElement> flightSelect = driver.findElements(flightSelection);
	      HashMap<Integer, Float> hm = new HashMap<Integer, Float>();
	      int val=1;
	      for(WebElement e : flightSelect)
	      {	    	  
	    	  String price=e.getText();
	    	  price = price.replace("$", "");	    				    	
	    	  hm.put(val,Float.parseFloat(price));
	    	  val++;
	      }
	        Set<Map.Entry<Integer, Float>> set = hm.entrySet();
	        List<Map.Entry<Integer, Float>> list = new ArrayList<Map.Entry<Integer, Float>>(
	                set);
	        Collections.sort(list, new Comparator<Map.Entry<Integer, Float>>() {
	            public int compare(Map.Entry<Integer, Float> o1,
	                    Map.Entry<Integer, Float> o2) {
	                return o2.getValue().compareTo(o1.getValue());
	            }	        });
	        
	       int rowVal =  list.get(list.size() - 1).getKey();
	       By rowXpath = By.xpath("//tr["+rowVal+"]//td[last()]//parent::tr//input[@class='btn btn-small']");
	       WebElement selectRow = driver.findElement(rowXpath); 
	       selectRow.click();
	       return new FlightUserDataEntry(driver);
	  }
	  
	  public FlightUserDataEntry clickOnChooseFlightButton()
	  {
		  By flightSelection = By.xpath("//tr[2]//td//parent::tr//input[@class='btn btn-small']"); 
		  System.out.println("Select the Flight");	  
	      WebElement flightSelect = driver.findElement(flightSelection);
	      flightSelect.click();
	      return new FlightUserDataEntry(driver);
	  }
	  
	  
}
