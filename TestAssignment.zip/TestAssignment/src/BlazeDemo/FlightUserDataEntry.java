package BlazeDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class FlightUserDataEntry {
	  WebDriver driver; 

	  public FlightUserDataEntry(WebDriver driver) 
	  { 
	    this.driver = driver; 
	  } 

	  By purchaseHeader = By.xpath("//h2[contains(text(),'Your flight from')]");
	  By fullName = By.id("inputName");
	  By address = By.id("address");
	  By city = By.id("city");
	  By state = By.id("state");
	  By zipCode = By.id("zipCode");
	  By cardType = By.id("cardType");
	  By creditCardNumber = By.id("creditCardNumber");
	  By creditCardMonth = By.id("creditCardMonth");
	  By creditCardYear = By.id("creditCardYear");
	  By nameOnCard = By.id("nameOnCard");
	  By purchaseFlight = By.xpath("//input[@class='btn btn-primary']");
	  	 		
		  public void enterFullName(String user_Name) 
		  {	 
		  WebElement name =driver.findElement(fullName); 
		  name.click(); 
		  name.sendKeys(user_Name);
		  }
		  
		  public void enterAddress(String user_Address) 
		  {	 
		  WebElement name =driver.findElement(address); 
		  name.click(); 
		  name.sendKeys(user_Address);
		  }
		  
		  public void enterCity(String user_City) 
		  {	 
		  WebElement name =driver.findElement(city); 
		  name.click(); 
		  name.sendKeys(user_City);
		  }
		  
		  public void enterState(String user_State) 
		  {	 
		  WebElement name =driver.findElement(state); 
		  name.click(); 
		  name.sendKeys(user_State);
		  }
		  
		  public void enterZipCode(String user_ZipCode) 
		  {	 
		  WebElement name =driver.findElement(zipCode); 
		  name.click(); 
		  name.sendKeys(user_ZipCode);
		  }
		  
		  public void selectCardType(String user_CardType)
		  {		      
		      Select selectCardType = new Select(driver.findElement(cardType));
		      selectCardType.selectByVisibleText(user_CardType);		     
		  }
		  
		  public void enterCreditCardNumber(String user_CreditCardNumber) 
		  {	 
		  WebElement cardNumber =driver.findElement(creditCardNumber); 
		  cardNumber.click(); 
		  cardNumber.sendKeys(user_CreditCardNumber);
		  }
		  
		  public void enterCreditCardMonth(String user_CreditCardMonth) 
		  {	 
		  WebElement cardMonth =driver.findElement(creditCardMonth); 
		  cardMonth.click(); 
		  cardMonth.sendKeys(user_CreditCardMonth);
		  }
		  
		  public void enterCreditCardYear(String user_CreditCardYear) 
		  {	 
		  WebElement cardYear =driver.findElement(creditCardYear); 
		  cardYear.click(); 
		  cardYear.sendKeys(user_CreditCardYear);
		  }
		  
		  public void enterNameOnCard(String user_NameOnCard) 
		  {	 
		  WebElement name =driver.findElement(nameOnCard); 
		  name.click(); 
		  name.sendKeys(user_NameOnCard);
		  }
		   
		  public ConfirmationPage clickOnPurchaseFlightButton()
		  {
			  System.out.println("Select the Flight");	  
		      WebElement login = driver.findElement(purchaseFlight);
		      login.click();
		      return new ConfirmationPage(driver);
		  }
		  
		   
		   
		   
		  
		 
		 
		 
}
